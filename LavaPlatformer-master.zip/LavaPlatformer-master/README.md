# LavaPlatformer

## Help and instructions: [LavaPlatformer wiki](https://github.com/OrangoMango/LavaPlatformer/wiki)

### Please run the Windows version in `C:\Users\<Username>\Directory\`

### `lavaPlatformer.py` is the main file but also others must be downloaded<br>

**Welcome on LavaPlatformer!**
Jump on the platforms by using `a` and `d` keys and get the coins. Attention! There are also transparent platforms and Lava is coming to touch you. With the coins you can buy more skins and unlock jobs. There are 3 different jobs, complete them and you will get as reward diamonds. With the diamonds you can buy chests. Earn keys to revive after game over! Have fun and beat yout best time, level and highscore! You find all statistics in the `Statistics` button! You can create multiple profiles by clicking on your avatar so you can play on the same device with many accounts. 😀😁😀


![Image](Data/showupimage.gif) <br>
![example](https://user-images.githubusercontent.com/61402409/84525997-dab06f80-acdc-11ea-8e9e-70201fb354cd.jpg)
Example of game
